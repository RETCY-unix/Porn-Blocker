#!/system/bin/sh
# FREEDOM LOCK - Installation Script
# This runs during module installation via Magisk

SKIPUNZIP=1

# Print with UI
ui_print "=================================================="
ui_print "     ███████╗██████╗ ███████╗███████╗██████╗  ██████╗ ███╗   ███╗"
ui_print "     ██╔════╝██╔══██╗██╔════╝██╔════╝██╔══██╗██╔═══██╗████╗ ████║"
ui_print "     █████╗  ██████╔╝█████╗  █████╗  ██║  ██║██║   ██║██╔████╔██║"
ui_print "     ██╔══╝  ██╔══██╗██╔══╝  ██╔══╝  ██║  ██║██║   ██║██║╚██╔╝██║"
ui_print "     ██║     ██║  ██║███████╗███████╗██████╔╝╚██████╔╝██║ ╚═╝ ██║"
ui_print "     ╚═╝     ╚═╝  ╚═╝╚══════╝╚══════╝╚═════╝  ╚═════╝ ╚═╝     ╚═╝"
ui_print "                         L O C K"
ui_print "=================================================="
ui_print ""
ui_print "  ⚠️  WARNING: THIS IS YOUR LAST CHANCE TO ABORT  ⚠️"
ui_print ""
ui_print "  Once installed, this module CANNOT be removed"
ui_print "  without completely reflashing your ROM."
ui_print ""
ui_print "  This will permanently block adult content."
ui_print ""
ui_print "=================================================="
ui_print ""

# Give user 5 seconds to think about it (they can pull battery/force reboot)
ui_print "  Installing in 5 seconds..."
sleep 1
ui_print "  4..."
sleep 1
ui_print "  3..."
sleep 1
ui_print "  2..."
sleep 1
ui_print "  1..."
sleep 1

ui_print ""
ui_print "  ✓ Point of no return passed."
ui_print ""

# Extract module files
ui_print "  → Extracting module files..."
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

# Set permissions
ui_print "  → Setting permissions..."
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755

# Set hosts file permissions
set_perm $MODPATH/system/etc/hosts 0 0 0644

# Create backup of hosts in protected location
ui_print "  → Creating protected backup..."
mkdir -p /data/adb/.freedomlock
cp $MODPATH/system/etc/hosts /data/adb/.freedomlock/hosts.backup
chmod 600 /data/adb/.freedomlock/hosts.backup

# Set module as 'core' so it loads before others
ui_print "  → Marking as core module..."
touch $MODPATH/core_module

# Create lock file to prevent normal uninstall
ui_print "  → Engaging lock mechanisms..."
touch /data/adb/.freedomlock_installed
chmod 000 /data/adb/.freedomlock_installed

# Modify module.prop to hide from manager
# (The description is already innocuous)

ui_print ""
ui_print "=================================================="
ui_print "  ✓ FREEDOM LOCK INSTALLED SUCCESSFULLY"
ui_print "=================================================="
ui_print ""
ui_print "  Protection Layers Active:"
ui_print "    ✓ Layer 1: DNS Blocking (700+ domains)"
ui_print "    ✓ Layer 2: iptables Firewall Rules"
ui_print "    ✓ Layer 3: Self-Healing Daemon"
ui_print "    ✓ Layer 4: Anti-Uninstall Protection"
ui_print "    ✓ Layer 5: System Persistence"
ui_print ""
ui_print "  A reboot is required to activate all layers."
ui_print ""
ui_print "  You made the right choice. Stay strong. 💪"
ui_print "=================================================="
ui_print ""
