#!/system/bin/sh
# FREEDOM LOCK - Post-FS-Data Script
# Runs very early in boot, before most services start
# This is the first line of defense

MODDIR=${0%/*}

# Log function
log() {
    echo "[FreedomLock] $1" >> /cache/freedomlock.log
}

log "Post-FS-Data script starting..."

# ============================================
# LAYER 1: HOSTS FILE PROTECTION
# ============================================

# Ensure hosts file is properly mounted
if [ -f "$MODDIR/system/etc/hosts" ]; then
    log "Hosts file found in module"
    
    # Set immutable flag if possible (requires specific kernel support)
    chattr +i "$MODDIR/system/etc/hosts" 2>/dev/null
    
    # Set strict permissions
    chmod 644 "$MODDIR/system/etc/hosts"
    chown root:root "$MODDIR/system/etc/hosts"
fi

# ============================================
# LAYER 5: SYSTEM PERSISTENCE
# Writes directly to /system - survives Magisk removal
# ============================================

# Check if we should write to real system
PERSISTENCE_FLAG="/data/adb/.freedomlock_persisted"

if [ ! -f "$PERSISTENCE_FLAG" ]; then
    log "First run - Writing to real /system partition"
    
    # Remount /system as read-write
    mount -o rw,remount /system 2>/dev/null
    
    if [ $? -eq 0 ]; then
        # Backup original hosts if exists
        if [ -f "/system/etc/hosts" ]; then
            cp /system/etc/hosts /system/etc/hosts.original 2>/dev/null
        fi
        
        # Copy our hosts file to real /system
        cp "$MODDIR/system/etc/hosts" /system/etc/hosts
        chmod 644 /system/etc/hosts
        chown root:root /system/etc/hosts
        
        # Try to make it immutable
        chattr +i /system/etc/hosts 2>/dev/null
        
        # Remount as read-only
        mount -o ro,remount /system 2>/dev/null
        
        # Mark as persisted
        touch "$PERSISTENCE_FLAG"
        log "Successfully wrote to /system partition"
    else
        log "Could not remount /system (this is normal on some ROMs)"
    fi
fi

# ============================================
# ANTI-TAMPER: Hide module from detection
# ============================================

# Create marker file so service.sh knows we ran
touch /data/adb/.freedomlock_active

log "Post-FS-Data script completed"
