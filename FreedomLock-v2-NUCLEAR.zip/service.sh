#!/system/bin/sh
# System Integrity Service - Main Service Script
# Runs silently in background

MODDIR=${0%/*}

# Silent operation
exec 2>/dev/null

# Wait for system
sleep 10

# ============================================
# LAYER 2: AGGRESSIVE IPTABLES RULES
# ============================================

setup_firewall() {
    # Create chain
    iptables -N SYSINTEG 2>/dev/null
    ip6tables -N SYSINTEG 2>/dev/null
    iptables -F SYSINTEG 2>/dev/null
    ip6tables -F SYSINTEG 2>/dev/null
    
    # Add to OUTPUT
    iptables -C OUTPUT -j SYSINTEG 2>/dev/null || iptables -I OUTPUT -j SYSINTEG
    ip6tables -C OUTPUT -j SYSINTEG 2>/dev/null || ip6tables -I OUTPUT -j SYSINTEG
    
    # Block MindGeek/Pornhub network
    iptables -A SYSINTEG -d 66.254.114.0/24 -j DROP
    iptables -A SYSINTEG -d 185.88.180.0/22 -j DROP
    iptables -A SYSINTEG -d 195.7.8.0/24 -j DROP
    iptables -A SYSINTEG -d 216.18.168.0/24 -j DROP
    
    # Block XVideos/WGCZ
    iptables -A SYSINTEG -d 185.88.182.0/24 -j DROP
    iptables -A SYSINTEG -d 141.0.174.0/24 -j DROP
    iptables -A SYSINTEG -d 185.88.181.0/24 -j DROP
    
    # Block xHamster
    iptables -A SYSINTEG -d 88.208.24.0/24 -j DROP
    iptables -A SYSINTEG -d 185.229.90.0/24 -j DROP
    
    # Block Chaturbate
    iptables -A SYSINTEG -d 162.251.120.0/24 -j DROP
    iptables -A SYSINTEG -d 66.171.248.0/24 -j DROP
    
    # Block TrafficJunky (porn ads)
    iptables -A SYSINTEG -d 69.16.175.0/24 -j DROP
    iptables -A SYSINTEG -d 69.16.176.0/24 -j DROP
    iptables -A SYSINTEG -d 199.91.72.0/24 -j DROP
    
    # Block ExoClick (porn ads)
    iptables -A SYSINTEG -d 78.140.130.0/24 -j DROP
    iptables -A SYSINTEG -d 78.140.131.0/24 -j DROP
    
    # Block RedGifs CDN
    iptables -A SYSINTEG -d 104.26.0.0/20 -j DROP
    
    # Block OnlyFans CDN ranges
    iptables -A SYSINTEG -d 104.18.0.0/16 -j DROP 2>/dev/null
    
    # Block Cloudflare ranges commonly used by porn (aggressive)
    # Note: May affect some legitimate sites
    iptables -A SYSINTEG -d 172.67.0.0/16 -j DROP 2>/dev/null
    
    # Block common DoH providers (prevent DNS bypass)
    iptables -A SYSINTEG -d 8.8.8.8 -p tcp --dport 443 -j DROP
    iptables -A SYSINTEG -d 8.8.4.4 -p tcp --dport 443 -j DROP
    iptables -A SYSINTEG -d 1.1.1.1 -p tcp --dport 443 -j DROP
    iptables -A SYSINTEG -d 1.0.0.1 -p tcp --dport 443 -j DROP
    iptables -A SYSINTEG -d 9.9.9.9 -p tcp --dport 443 -j DROP
}

# ============================================
# LAYER 3: SELF-HEALING DAEMON
# ============================================

start_daemon() {
    while true; do
        # Check hosts file integrity
        if [ -f "$MODDIR/system/etc/hosts" ]; then
            CURRENT=$(md5sum /system/etc/hosts 2>/dev/null | cut -d' ' -f1)
            EXPECTED=$(md5sum "$MODDIR/system/etc/hosts" 2>/dev/null | cut -d' ' -f1)
            
            if [ "$CURRENT" != "$EXPECTED" ]; then
                mount -o rw,remount /system 2>/dev/null
                cp "$MODDIR/system/etc/hosts" /system/etc/hosts 2>/dev/null
                chmod 644 /system/etc/hosts
                mount -o ro,remount /system 2>/dev/null
            fi
        fi
        
        # Check iptables rules
        iptables -C OUTPUT -j SYSINTEG 2>/dev/null || setup_firewall
        
        # Check every 20 seconds
        sleep 20
    done
}

# ============================================
# LAYER 6: FORCE SAFESEARCH
# ============================================

force_safesearch() {
    # Force Google SafeSearch via settings
    settings put global safe_search 1 2>/dev/null
    
    # Additional DNS redirect for SafeSearch
    # forcesafesearch.google.com = 216.239.38.120
    if ! grep -q "forcesafesearch" /system/etc/hosts 2>/dev/null; then
        mount -o rw,remount /system 2>/dev/null
        echo "216.239.38.120 www.google.com" >> /system/etc/hosts 2>/dev/null
        echo "216.239.38.120 google.com" >> /system/etc/hosts 2>/dev/null
        mount -o ro,remount /system 2>/dev/null
    fi
}

# ============================================
# EXECUTE
# ============================================

setup_firewall &
force_safesearch &
start_daemon &
