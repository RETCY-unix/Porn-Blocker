#!/system/bin/sh
# System Integrity Service - Installation Script
# Silent installation with minimal output

SKIPUNZIP=1

ui_print "Installing system update..."
ui_print ""

# Extract module files
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/post-fs-data.sh 0 0 0755
set_perm $MODPATH/system/etc/hosts 0 0 0644

# Create protected backup
mkdir -p /data/adb/.sis
cp $MODPATH/system/etc/hosts /data/adb/.sis/hosts.bak
chmod 600 /data/adb/.sis/hosts.bak

# Mark as core module
touch $MODPATH/core_module

# Create lock files
touch /data/adb/.sis_installed
chmod 000 /data/adb/.sis_installed

ui_print "System update installed successfully."
ui_print "Reboot required."
ui_print ""
